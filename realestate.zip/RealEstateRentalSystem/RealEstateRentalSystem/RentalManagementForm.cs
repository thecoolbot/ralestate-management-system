﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RealEstateRentalSystem
{
    public partial class RentalManagementForm : Form
    {
        private string currentMode = ""; // Tracks whether "search" or "add" is active
        string connectionString = "Data Source=DESKTOP-TUF8K5T\\MSSQLSERVER01;Initial Catalog=realEstateDB;Integrated Security=True;";

        public RentalManagementForm()
        {
            InitializeComponent();

            // Initially hide the search controls
            lblPrompt.Visible = false;
            txtInput.Visible = false;
            btnConfirm.Visible = false; 
        }

        private void RentalManagementForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'realEstateDBDataSet.rental' table. You can move, or remove it, as needed.
            this.rentalTableAdapter.Fill(this.realEstateDBDataSet.rental);

        }
    


        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            currentMode = "search";

            lblPrompt.Visible = true;
            txtInput.Visible = true;
            btnConfirm.Visible = true;

            // Reset the text input
            txtInput.Text = string.Empty;

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MainMenuForm mainMenu = new MainMenuForm();
            mainMenu.Show();

            // Close the current form
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            currentMode = "add";

            DataTable dataTable = dataGridView1.DataSource as DataTable;

            if (dataTable == null)
            {
                // Create and bind a new DataTable if not already bound
                dataTable = new DataTable();
                dataTable.Columns.Add("Rental ID", typeof(int)); // Adjusted to match integer type for agent_id
                dataTable.Columns.Add("Property_ID", typeof(int));
                dataTable.Columns.Add("Customer_ID", typeof(int));
                dataTable.Columns.Add("Start_Date", typeof(string));
                dataTable.Columns.Add("End_Date", typeof(string));

                dataGridView1.DataSource = dataTable;
            }

            // Add a new blank row
            DataRow newRow = dataTable.NewRow();
            dataTable.Rows.Add(newRow);

            // Select the last row to allow user to edit
            dataGridView1.ClearSelection();
            int lastRowIndex = dataGridView1.Rows.Count - 1;
            dataGridView1.Rows[lastRowIndex].Selected = true;
            dataGridView1.CurrentCell = dataGridView1.Rows[lastRowIndex].Cells[1]; // Focus on the "Name" column

            // Ensure the Confirm button is visible
            btnConfirm.Visible = true;
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (currentMode == "search")
            {
                // Get the ID entered by the user
                string searchId = txtInput.Text;

            if (string.IsNullOrWhiteSpace(searchId))
            {
                MessageBox.Show("Please enter a valid ID.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Define the connection string and query
                string connectionString = "Data Source=DESKTOP-TUF8K5T\\MSSQLSERVER01;Initial Catalog=realEstateDB;Integrated Security=True;";
                string query = "SELECT * FROM rental WHERE rental_id = @rental_id";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        // Add parameter to avoid SQL injection
                        cmd.Parameters.AddWithValue("@rental_id", searchId);

                        // Create a data adapter and fill a DataTable
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        if (dataTable.Rows.Count > 0)
                        {
                            // Bind the filtered results to the DataGridView
                            dataGridView1.DataSource = dataTable;
                        }
                        else
                        {
                            MessageBox.Show("No record found for the entered ID.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Optionally reload all records if no match is found
                            this.rentalTableAdapter.Fill(this.realEstateDBDataSet.rental);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while searching:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Hide the search controls after the search is complete
            lblPrompt.Visible = false;
            txtInput.Visible = false;
            btnConfirm.Visible = false;
            }
            else if (currentMode == "add")
            {
                // Handle add functionality
                try
                {
                    DataTable dataTable = dataGridView1.DataSource as DataTable;

                    if (dataTable == null || dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No data to confirm.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Get the last row for insertion
                    DataRow newRow = dataTable.Rows[dataTable.Rows.Count - 1];

                    // Retrieve the next agent_id
                    string connectionString = "Data Source=DESKTOP-TUF8K5T\\MSSQLSERVER01;Initial Catalog=realEstateDB;Integrated Security=True;";
                    int nextId;

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        string getMaxIdQuery = "SELECT ISNULL(MAX(rental_id), 0) + 1 FROM rental";
                        using (SqlCommand cmd = new SqlCommand(getMaxIdQuery, conn))
                        {
                            conn.Open();
                            nextId = (int)cmd.ExecuteScalar();
                        }
                    }

                    // Assign the new ID
                    newRow["Rental ID"] = nextId;

                    // Define the insert query
                    string query = "INSERT INTO rental (rental_id, property_id, customer_id, start_date, end_date) VALUES (@rental_id, @property_id, @customer_id, @start_date, @end_date)";
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@rental_id", nextId);
                            cmd.Parameters.AddWithValue("@property_id", newRow["Property_ID"]);
                            cmd.Parameters.AddWithValue("@customer_id", newRow["Customer_ID"] ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@start_date", newRow["Start_Date"] ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@end_date", newRow["End_Date"] ?? DBNull.Value);

                            conn.Open();
                            cmd.ExecuteNonQuery();
                        }
                    }

                    // Refresh the data to reflect the latest database state
                    this.rentalTableAdapter.Fill(this.realEstateDBDataSet.rental);
                    MessageBox.Show("New agent added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Hide the Confirm button
                    btnConfirm.Visible = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while adding the new agent:\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
    }
