﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RealEstateRentalSystem
{
    public partial class MainMenuForm : Form
    {
        public MainMenuForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OwnerManagementForm ownerForm = new OwnerManagementForm();

            // Show the new form
            ownerForm.Show();

            // Close the current form (MainMenuForm)
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to exit?", "Exit Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirmResult == DialogResult.Yes)
            {
                Application.Exit(); // Exits the application entirely
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LocationManagementForm ownerForm = new LocationManagementForm();

            // Show the new form
            ownerForm.Show();

            // Close the current form (MainMenuForm)
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PropertyManagementForm ownerForm = new PropertyManagementForm();

            // Show the new form
            ownerForm.Show();

            // Close the current form (MainMenuForm)
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CustomersManagementForm ownerForm = new CustomersManagementForm();

            // Show the new form
            ownerForm.Show();

            // Close the current form (MainMenuForm)
            this.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            RentalManagementForm ownerForm = new RentalManagementForm();

            // Show the new form
            ownerForm.Show();

            // Close the current form (MainMenuForm)
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SaleManagementForm ownerForm = new SaleManagementForm();

            // Show the new form
            ownerForm.Show();

            // Close the current form (MainMenuForm)
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            AgentManagementForm ownerForm = new AgentManagementForm();

            // Show the new form
            ownerForm.Show();

            // Close the current form (MainMenuForm)
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            InspectionManagementForm ownerForm = new InspectionManagementForm();

            // Show the new form
            ownerForm.Show();

            // Close the current form (MainMenuForm)
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MaintenanceRequestManagementForm ownerForm = new MaintenanceRequestManagementForm();

            // Show the new form
            ownerForm.Show();

            // Close the current form (MainMenuForm)
            this.Hide();
        }
    }
}
